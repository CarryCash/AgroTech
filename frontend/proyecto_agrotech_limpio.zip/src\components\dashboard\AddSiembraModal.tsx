import React from 'react';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue
} from '@/components/ui/select';
import { Sprout, Calendar, MapPin, Hash, Save } from 'lucide-react';
import { parcelas } from '@/data/mockData'; // Para listar las parcelas disponibles
import { Siembra } from '@/types/farms';


interface AddSiembraModalProps {
    open: boolean;
    onClose: () => void;
    initialData?: Siembra | null;
}

const AddSiembraModal: React.FC<AddSiembraModalProps> = ({ open, onClose, initialData }) => {
    const isEditing = !!initialData;
    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="glass-card border-white/10 sm:max-w-md bg-[#181111] text-cream">
                <DialogHeader>
                    <DialogTitle className="text-2xl font-display font-bold flex items-center gap-2 text-avocado-pulp">
                        <Sprout className="w-6 h-6" />
                        Nueva Siembra
                    </DialogTitle>
                </DialogHeader>

                <div className="grid gap-6 py-4">
                    {/* Selección de Variedad */}
                    <div className="grid gap-2">
                        <Label className="text-xs uppercase font-bold text-muted-foreground">Variedad de Aguacate</Label>
                        <Select>
                            <SelectTrigger className="bg-white/5 border-white/10">
                                <SelectValue placeholder="Seleccionar variedad" />
                            </SelectTrigger>
                            <SelectContent className="bg-[#181111] border-white/10 text-cream">
                                <SelectItem value="1">Hass</SelectItem>
                                <SelectItem value="2">Fuerte</SelectItem>
                                <SelectItem value="3">Bacon</SelectItem>
                                <SelectItem value="4">Reed</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    {/* Selección de Parcela */}
                    <div className="grid gap-2">
                        <Label className="text-xs uppercase font-bold text-muted-foreground flex items-center gap-1">
                            <MapPin className="w-3 h-3" /> Parcela Destino
                        </Label>
                        <Select>
                            <SelectTrigger className="bg-white/5 border-white/10">
                                <SelectValue placeholder="Seleccionar parcela" />
                            </SelectTrigger>
                            <SelectContent className="bg-[#181111] border-white/10 text-cream">
                                {parcelas.map(p => (
                                    <SelectItem key={p.id} value={p.id.toString()}>{p.nombre} ({p.area_ha} ha)</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        {/* Cantidad de Plantas */}
                        <div className="grid gap-2">
                            <Label htmlFor="plantas" className="text-xs uppercase font-bold text-muted-foreground flex items-center gap-1">
                                <Hash className="w-3 h-3" /> Cant. Plantas
                            </Label>
                            <Input
                                id="plantas"
                                type="number"
                                placeholder="Ej: 120"
                                className="bg-white/5 border-white/10"
                            />
                        </div>

                        {/* Fecha de Siembra */}
                        <div className="grid gap-2">
                            <Label htmlFor="fecha" className="text-xs uppercase font-bold text-muted-foreground flex items-center gap-1">
                                <Calendar className="w-3 h-3" /> Fecha
                            </Label>
                            <Input
                                id="fecha"
                                type="date"
                                className="bg-white/5 border-white/10 appearance-none"
                            />
                        </div>
                    </div>
                </div>

                <DialogFooter className="gap-2 sm:gap-0">
                    <Button variant="ghost" onClick={onClose} className="hover:bg-white/5 text-muted-foreground">
                        Cancelar
                    </Button>
                    <Button className="bg-avocado-pulp hover:bg-avocado-dark text-white font-bold gap-2">
                        <Save className="w-4 h-4" />
                        Registrar Siembra
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default AddSiembraModal;