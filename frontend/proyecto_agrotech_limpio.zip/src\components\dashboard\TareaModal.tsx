import React, { useState } from 'react';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Droplets, Scissors, Wind, Calendar, User, MapPin, Loader2, Save } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { parcelas, users } from '@/data/mockData'; // Importamos tus datos

interface TareaModalProps {
    open: boolean;
    onClose: () => void;
}

const TareaModal: React.FC<TareaModalProps> = ({ open, onClose }) => {
    // ESTADOS DEL FORMULARIO
    const [tipo, setTipo] = useState('Riego');
    const [parcelaId, setParcelaId] = useState('');
    const [trabajadorId, setTrabajadorId] = useState('');
    const [fecha, setFecha] = useState(new Date().toISOString().split('T')[0]);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const types = [
        { id: 'Riego', icon: <Droplets className="w-5 h-5" />, label: 'Riego' },
        { id: 'Poda', icon: <Scissors className="w-5 h-5" />, label: 'Poda' },
        { id: 'Fumigacion', icon: <Wind className="w-5 h-5" />, label: 'Fumigación' },
    ];

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);

        // Simulación de llamada a la API
        await new Promise(resolve => setTimeout(resolve, 1000));

        toast({
            title: '¡Tarea Programada!',
            description: `${tipo} en la parcela seleccionada para el ${fecha}`,
        });

        setIsSubmitting(false);
        onClose();
        // Resetear formulario
        setParcelaId('');
        setTrabajadorId('');
    };

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="glass-card border-accent/20 sm:max-w-md">
                <DialogHeader>
                    <div className="flex items-center gap-3 mb-2">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-avocado-pulp/20 to-avocado-dark/20 flex items-center justify-center">
                            <Save className="w-6 h-6 text-avocado-pulp" />
                        </div>
                        <div>
                            <DialogTitle className="font-display text-xl">Nueva Tarea</DialogTitle>
                            <DialogDescription>
                                Programe una actividad para el personal
                            </DialogDescription>
                        </div>
                    </div>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-5 mt-4">
                    {/* SELECTOR DE TIPO (LOS 3 BOTONES) */}
                    <div className="space-y-2">
                        <Label>Tipo de Actividad</Label>
                        <div className="grid grid-cols-3 gap-2">
                            {types.map((t) => (
                                <button
                                    key={t.id}
                                    type="button"
                                    onClick={() => setTipo(t.id)}
                                    className={`p-3 rounded-lg border-2 transition-all flex flex-col items-center gap-1
                                        ${tipo === t.id
                                            ? 'border-avocado-pulp bg-avocado-pulp/10 text-avocado-pulp'
                                            : 'border-border bg-muted/30 text-muted-foreground hover:bg-muted/50'
                                        }`}
                                >
                                    {t.icon}
                                    <span className="text-xs font-medium">{t.label}</span>
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* SELECT DE PARCELA */}
                    <div className="space-y-2">
                        <Label htmlFor="parcela">Parcela</Label>
                        <Select value={parcelaId} onValueChange={setParcelaId} required>
                            <SelectTrigger className="bg-muted/50 pl-10 relative">
                                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                                <SelectValue placeholder="Seleccione parcela" />
                            </SelectTrigger>
                            <SelectContent>
                                {parcelas.map((p) => (
                                    <SelectItem key={p.id} value={p.id.toString()}>{p.nombre}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    {/* SELECT DE TRABAJADOR */}
                    <div className="space-y-2">
                        <Label htmlFor="trabajador">Asignar a</Label>
                        <Select value={trabajadorId} onValueChange={setTrabajadorId} required>
                            <SelectTrigger className="bg-muted/50 pl-10 relative">
                                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                                <SelectValue placeholder="Seleccione personal" />
                            </SelectTrigger>
                            <SelectContent>
                                {users.filter(u => u.rol !== 'Administrador').map((u) => (
                                    <SelectItem key={u.id} value={u.id.toString()}>{u.username}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    {/* FECHA */}
                    <div className="space-y-2">
                        <Label htmlFor="fecha">Fecha Programada</Label>
                        <div className="relative">
                            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <input
                                id="fecha"
                                type="date"
                                value={fecha}
                                onChange={(e) => setFecha(e.target.value)}
                                className="w-full flex h-10 rounded-md border border-input bg-muted/50 px-3 py-2 text-sm pl-10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                required
                            />
                        </div>
                    </div>

                    <DialogFooter>
                        <Button type="button" variant="ghost" onClick={onClose}>
                            Cancelar
                        </Button>
                        <Button type="submit" className="bg-avocado-pulp text-hass-black hover:bg-avocado-pulp/90" disabled={isSubmitting}>
                            {isSubmitting ? (
                                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                            ) : 'Guardar Tarea'}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default TareaModal;