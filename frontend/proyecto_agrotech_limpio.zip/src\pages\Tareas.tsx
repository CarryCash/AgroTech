import React, { useState } from 'react';
import TareaCard from '@/components/dashboard/TareaCard';
import { tareas } from '@/data/mockData';
import { ClipboardList, Plus } from 'lucide-react'; // Cambié Scale por Plus
import { toast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import TareaModal from '@/components/dashboard/TareaModal';

const Tareas: React.FC = () => {
    // ESTADO PARA CONTROLAR EL MODAL
    const [tareasModalOpen, setTareasModalOpen] = useState(false);

    const handleStart = (id: number) => {
        toast({ title: 'Tarea iniciada', description: `La tarea #${id} ahora está en progreso.` });
    };

    const handleComplete = (id: number) => {
        toast({ title: '¡Tarea completada!', description: 'El registro se ha actualizado con éxito.' });
    };

    // FILTROS DE ESTADOS (Asegúrate que coincidan con tus datos en mockData)
    const pendientes = tareas.filter(t => t.estado === 'Pendiente');
    const enProgreso = tareas.filter(t => t.estado === 'EnProgreso');
    const completadas = tareas.filter(t => t.estado === 'Completada');

    return (
        <div className="space-y-6 animate-fade-in">
            {/* CABECERA */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
                        <ClipboardList className="w-8 h-8 text-avocado-pulp" />
                        Gestión de Tareas
                    </h1>
                    <p className="text-muted-foreground mt-1">Administra las actividades de riego, poda y fumigación</p>
                </div>
                
                {/* BOTÓN PARA ABRIR EL MODAL */}
                <Button 
                    className="bg-avocado-pulp text-hass-black hover:bg-avocado-pulp/90 font-bold gap-2"
                    onClick={() => setTareasModalOpen(true)}
                >
                    <Plus className="w-5 h-5" />
                    Nueva Tarea
                </Button>
            </div>

            {/* MODAL DE TAREAS */}
            <TareaModal 
                open={tareasModalOpen} 
                onClose={() => setTareasModalOpen(false)} 
            />

            {/* LISTADO POR ESTADOS */}
            <div className="space-y-8">
                {pendientes.length > 0 && (
                    <section>
                        <h2 className="text-lg font-semibold text-warning mb-4 flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-warning animate-pulse" />
                            Pendientes ({pendientes.length})
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {pendientes.map((tarea) => (
                                <TareaCard key={tarea.id} tarea={tarea} onStart={handleStart} onComplete={handleComplete} />
                            ))}
                        </div>
                    </section>
                )}

                {enProgreso.length > 0 && (
                    <section>
                        <h2 className="text-lg font-semibold text-info mb-4 flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-info animate-pulse" />
                            En Progreso ({enProgreso.length})
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {enProgreso.map((tarea) => (
                                <TareaCard key={tarea.id} tarea={tarea} onComplete={handleComplete} />
                            ))}
                        </div>
                    </section>
                )}

                {completadas.length > 0 && (
                    <section>
                        <h2 className="text-lg font-semibold text-success mb-4 flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-success" />
                            Completadas ({completadas.length})
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {completadas.map((tarea) => (
                                <TareaCard key={tarea.id} tarea={tarea} />
                            ))}
                        </div>
                    </section>
                )}

                {tareas.length === 0 && (
                    <div className="text-center py-20 border-2 border-dashed border-seed-brown rounded-xl">
                        <p className="text-muted-foreground text-lg">No hay tareas programadas para esta finca.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Tareas;