import React from 'react';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button'; // Importamos el botón de UI
import {
    Sprout,
    MapPin,
    TrendingUp,
    Info,
    Edit2, // Icono de edición
    History
} from 'lucide-react';
import { Siembra, Parcela, Variedad } from '@/types/farms';

interface SiembraDetalleModalProps {
    siembra: Siembra | null;
    parcela: Parcela | undefined;
    variedad: Variedad | undefined;
    open: boolean;
    onClose: () => void;
    onEdit: () => void; // Nueva prop para manejar la edición
}

const SiembraDetalleModal: React.FC<SiembraDetalleModalProps> = ({
    siembra,
    parcela,
    variedad,
    open,
    onClose,
    onEdit
}) => {
    if (!siembra) return null;

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="glass-card border-white/10 sm:max-w-lg bg-[#181111] text-cream p-0 overflow-hidden">
                {/* Banner Superior Decorativo */}
                <div className="h-32 bg-gradient-to-br from-avocado-dark to-avocado-pulp/20 relative">
                    <div className="absolute -bottom-6 left-8 p-4 bg-[#181111] border border-white/10 rounded-2xl shadow-xl">
                        <Sprout className="w-8 h-8 text-avocado-pulp" />
                    </div>
                </div>

                <div className="p-8 pt-10 space-y-6">
                    <DialogHeader>
                        <div className="flex justify-between items-start">
                            <div>
                                <DialogTitle className="text-3xl font-display font-bold text-white">
                                    {variedad?.nombre}
                                </DialogTitle>
                                <p className="text-avocado-pulp font-medium flex items-center gap-1 mt-1">
                                    <MapPin className="w-3 h-3" /> Parcela {parcela?.nombre}
                                </p>
                            </div>
                            <Badge className="bg-success/20 text-success border-success/30">
                                En Desarrollo
                            </Badge>
                        </div>
                    </DialogHeader>

                    {/* Estadísticas de la Siembra */}
                    <div className="grid grid-cols-2 gap-3">
                        <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                            <p className="text-[10px] uppercase font-bold text-muted-foreground mb-1 text-avocado-cream/50">Total Plantas</p>
                            <p className="text-2xl font-display font-bold text-white">{siembra.cant_plantas}</p>
                        </div>
                        <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                            <p className="text-[10px] uppercase font-bold text-muted-foreground mb-1 text-avocado-cream/50">Fecha Plantación</p>
                            <p className="text-sm font-semibold">{new Date(siembra.fecha).toLocaleDateString('es-EC', { dateStyle: 'medium' })}</p>
                        </div>
                    </div>

                    {/* Información Detallada */}
                    <div className="space-y-4">
                        <div className="flex items-start gap-3 p-3 rounded-lg bg-white/5 border-l-2 border-l-avocado-pulp">
                            <Info className="w-5 h-5 text-avocado-pulp mt-1 shrink-0" />
                            <div>
                                <h4 className="text-xs font-bold text-white uppercase tracking-tighter">Ficha Técnica</h4>
                                <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                                    {variedad?.descripcion} Esta variedad requiere un monitoreo constante de la humedad en la zona radicular.
                                </p>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <h4 className="text-xs font-bold text-muted-foreground uppercase flex items-center gap-2">
                                <TrendingUp className="w-4 h-4" /> Proyección de Crecimiento
                            </h4>
                            <div className="w-full bg-white/5 rounded-full h-2">
                                <div className="bg-avocado-pulp h-2 rounded-full w-[35%]" />
                            </div>
                            <p className="text-[10px] text-muted-foreground text-right">35% del ciclo completado</p>
                        </div>
                    </div>

                    {/* Footer con Acciones */}
                    <div className="pt-4 border-t border-white/5 flex justify-between items-center">
                        <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-avocado-dark border border-white/10 flex items-center justify-center text-[10px] font-bold text-avocado-pulp">
                                DI
                            </div>
                            <div className="flex flex-col">
                                <span className="text-[10px] text-muted-foreground uppercase font-bold leading-none">Técnico</span>
                                <span className="text-xs font-medium text-cream">Diego Intriago</span>
                            </div>
                        </div>

                        <div className="flex gap-2">
                            <Button
                                variant="ghost"
                                size="sm"
                                className="text-muted-foreground hover:text-white hover:bg-white/5 text-[10px] font-bold uppercase"
                            >
                                <History className="w-3 h-3 mr-1" />
                                Historial
                            </Button>

                            {/* BOTÓN EDITAR */}
                            <Button
                                size="sm"
                                onClick={onEdit}
                                className="bg-avocado-pulp hover:bg-avocado-dark text-white text-[10px] font-bold uppercase px-4 transition-all"
                            >
                                <Edit2 className="w-3 h-3 mr-1" />
                                Editar
                            </Button>
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default SiembraDetalleModal;