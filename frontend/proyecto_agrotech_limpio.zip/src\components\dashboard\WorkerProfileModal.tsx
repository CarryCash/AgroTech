import React from 'react';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Mail, Calendar, ClipboardCheck, Clock, ShieldCheck } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Trabajador } from '@/types/farms';

interface WorkerProfileModalProps {
    worker: Trabajador | null;
    open: boolean;
    onClose: () => void;
}

const WorkerProfileModal: React.FC<WorkerProfileModalProps> = ({ worker, open, onClose }) => {
    if (!worker) return null;

    const roleColors = {
        Peon: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
        Tecnico: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
        Administrador: 'bg-green-500/10 text-green-500 border-green-500/20',
    };

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="glass-card border-white/10 sm:max-w-md bg-[#181111] text-cream overflow-hidden">
                <DialogHeader className="relative pb-20">
                    {/* Fondo decorativo superior */}
                    <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-r from-avocado-dark to-avocado-pulp/40 opacity-30" />

                    <div className="relative flex flex-col items-center pt-8">
                        {/* Avatar Grande */}
                        <div className="w-24 h-24 rounded-2xl bg-[#261c1c] border-4 border-[#181111] flex items-center justify-center text-3xl font-bold text-avocado-pulp shadow-xl">
                            {worker.nombre.split(' ').map((n: string) => n[0]).join('')}
                        </div>

                        <DialogTitle className="mt-4 text-2xl font-display font-bold">{worker.nombre}</DialogTitle>
                        <Badge className={cn("mt-2 px-3 py-1 border", roleColors[worker.rol as keyof typeof roleColors])}>
                            <ShieldCheck className="w-3 h-3 mr-1" />
                            {worker.rol}
                        </Badge>
                    </div>
                </DialogHeader>

                <div className="space-y-6 px-2">
                    {/* Información de Contacto */}
                    <div className="grid grid-cols-1 gap-3">
                        <div className="flex items-center p-3 rounded-lg bg-white/5 border border-white/5">
                            <Mail className="w-5 h-5 text-avocado-pulp mr-3" />
                            <div>
                                <p className="text-xs text-muted-foreground uppercase font-bold tracking-tighter">Correo Electrónico</p>
                                <p className="text-sm">{worker.contacto || `${worker.nombre}@fincaelsol.com`}</p>
                            </div>
                        </div>
                    </div>

                    {/* Estadísticas Rápidas (Simuladas para el Dashboard) */}
                    <div className="grid grid-cols-2 gap-3">
                        <div className="p-4 rounded-xl bg-gradient-to-br from-white/5 to-transparent border border-white/5 text-center">
                            <ClipboardCheck className="w-6 h-6 text-success mx-auto mb-2" />
                            <p className="text-2xl font-bold italic">24</p>
                            <p className="text-[10px] text-muted-foreground uppercase">Tareas Completadas</p>
                        </div>
                        <div className="p-4 rounded-xl bg-gradient-to-br from-white/5 to-transparent border border-white/5 text-center">
                            <Clock className="w-6 h-6 text-warning mx-auto mb-2" />
                            <p className="text-2xl font-bold italic">3</p>
                            <p className="text-[10px] text-muted-foreground uppercase">En Progreso</p>
                        </div>
                    </div>

                    {/* Registro de Actividad Reciente */}
                    <div className="space-y-3">
                        <h4 className="text-sm font-bold text-avocado-cream flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            Actividad Reciente
                        </h4>
                        <div className="text-xs space-y-2">
                            <div className="flex justify-between p-2 rounded bg-white/5 border-l-2 border-l-success">
                                <span>Cosecha en Parcela A</span>
                                <span className="text-muted-foreground">Ayer</span>
                            </div>
                            <div className="flex justify-between p-2 rounded bg-white/5 border-l-2 border-l-info">
                                <span>Riego programado</span>
                                <span className="text-muted-foreground">Hace 3 días</span>
                            </div>
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default WorkerProfileModal;