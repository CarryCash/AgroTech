import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button'; // Importamos Button
import { insumos } from '@/data/mockData';
import { Package, AlertTriangle, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';
import InsumoModal from '@/components/dashboard/InsumoModal'; // Importamos el Modal

const Insumos: React.FC = () => {
    // ESTADO PARA EL MODAL
    const [insumoModalOpen, setInsumoModalOpen] = useState(false);

    // Tipos actualizados para coincidir con el Modal
    const tipoColors: Record<string, string> = {
        Fertilizante: 'bg-success/20 text-success border-success/30',
        Fungicida: 'bg-warning/20 text-warning border-warning/30',
        Herbicida: 'bg-destructive/20 text-destructive border-destructive/30',
        Insecticida: 'bg-info/20 text-info border-info/30',
        Otros: 'bg-muted text-muted-foreground',
    };

    return (
        <div className="space-y-6 animate-fade-in">
            {/* CABECERA CON BOTÓN */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
                        <Package className="w-8 h-8 text-avocado-pulp" />
                        Inventario de Insumos
                    </h1>
                    <p className="text-muted-foreground mt-1">Control de stock y caducidad de materiales</p>
                </div>

                <Button 
                    onClick={() => setInsumoModalOpen(true)}
                    className="bg-[#A7C957] hover:bg-[#A7C957] text-white font-bold gap-2"
                >
                    <Plus className="w-5 h-5" />
                    Registrar Insumo
                </Button>
            </div>

            {/* MODAL */}
            <InsumoModal 
                open={insumoModalOpen} 
                onClose={() => setInsumoModalOpen(false)} 
            />

            {/* GRID DE TARJETAS */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {insumos.map((insumo) => {
                    const lowStock = insumo.stock_kg < 100;

                    return (
                        <div
                            key={insumo.id}
                            className={cn(
                                'glass-card p-5 hover:scale-[1.02] transition-all duration-300 border border-white/5',
                                lowStock && 'border-l-4 border-l-warning bg-warning/5'
                            )}
                        >
                            <div className="flex items-start justify-between mb-4">
                                <Badge 
                                    variant="outline"
                                    className={cn("font-medium", tipoColors[insumo.tipo] || tipoColors.Otros)}
                                >
                                    {insumo.tipo}
                                </Badge>
                                <div className="text-right">
                                    <div className="flex items-baseline justify-end">
                                        <span className="text-2xl font-display font-bold text-avocado-pulp">
                                            {insumo.stock_kg}
                                        </span>
                                        <span className="text-xs text-muted-foreground ml-1 uppercase font-semibold">
                                            kg
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <h3 className="font-display text-lg font-semibold text-foreground mb-3">
                                {insumo.nombre}
                            </h3>

                            <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5">
                                {lowStock ? (
                                    <div className="flex items-center gap-2 text-sm text-warning font-medium animate-pulse">
                                        <AlertTriangle className="w-4 h-4" />
                                        Reabastecimiento urgente
                                    </div>
                                ) : (
                                    <div className="text-xs text-muted-foreground">
                                        Estado: <span className="text-success">Óptimo</span>
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* VISTA VACÍA */}
            {insumos.length === 0 && (
                <div className="text-center py-20 border-2 border-dashed border-white/5 rounded-xl">
                    <Package className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-20" />
                    <p className="text-muted-foreground">No hay insumos registrados en el inventario.</p>
                </div>
            )}
        </div>
    );
};

export default Insumos;