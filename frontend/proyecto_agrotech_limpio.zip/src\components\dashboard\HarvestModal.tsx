import React, { useState } from 'react';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Scale, Calendar, Star, Loader2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { siembras, variedades, parcelas } from '@/data/mockData';

interface HarvestModalProps {
    open: boolean;
    onClose: () => void;
}

const HarvestModal: React.FC<HarvestModalProps> = ({ open, onClose }) => {
    const [siembraId, setSiembraId] = useState('');
    const [fecha, setFecha] = useState(new Date().toISOString().split('T')[0]);
    const [cantKg, setCantKg] = useState('');
    const [calidad, setCalidad] = useState<'Alta' | 'Media' | 'Baja'>('Media');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);

        // Simulate API call (sp_registrar_cosecha logic)
        await new Promise(resolve => setTimeout(resolve, 1000));

        toast({
            title: '¡Cosecha registrada!',
            description: `Se registraron ${cantKg} kg de calidad ${calidad}`,
        });

        setIsSubmitting(false);
        onClose();
        // Reset form
        setSiembraId('');
        setCantKg('');
        setCalidad('Media');
    };

    const getSiembraLabel = (siembra: typeof siembras[0]) => {
        const parcela = parcelas.find(p => p.id === siembra.parcela_id);
        const variedad = variedades.find(v => v.id === siembra.variedad_id);
        return `${parcela?.nombre} - ${variedad?.nombre} (${new Date(siembra.fecha).toLocaleDateString('es-EC')})`;
    };

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="glass-card border-accent/20 sm:max-w-md">
                <DialogHeader>
                    <div className="flex items-center gap-3 mb-2">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent/20 to-primary/20 flex items-center justify-center">
                            <Scale className="w-6 h-6 text-accent" />
                        </div>
                        <div>
                            <DialogTitle className="font-display text-xl">Registrar Cosecha</DialogTitle>
                            <DialogDescription>
                                Ingrese los datos de la cosecha realizada
                            </DialogDescription>
                        </div>
                    </div>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-5 mt-4">
                    <div className="space-y-2">
                        <Label htmlFor="siembra">Siembra</Label>
                        <Select value={siembraId} onValueChange={setSiembraId} required>
                            <SelectTrigger className="bg-muted/50">
                                <SelectValue placeholder="Seleccione la siembra" />
                            </SelectTrigger>
                            <SelectContent>
                                {siembras.map((siembra) => (
                                    <SelectItem key={siembra.id} value={siembra.id.toString()}>
                                        {getSiembraLabel(siembra)}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="fecha">Fecha</Label>
                            <div className="relative">
                                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                                <Input
                                    id="fecha"
                                    type="date"
                                    value={fecha}
                                    onChange={(e) => setFecha(e.target.value)}
                                    className="bg-muted/50 pl-10"
                                    required
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="cantidad">Cantidad (kg)</Label>
                            <div className="relative">
                                <Scale className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                                <Input
                                    id="cantidad"
                                    type="number"
                                    min="1"
                                    value={cantKg}
                                    onChange={(e) => setCantKg(e.target.value)}
                                    placeholder="0"
                                    className="bg-muted/50 pl-10"
                                    required
                                />
                            </div>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label>Calidad</Label>
                        <div className="grid grid-cols-3 gap-2">
                            {(['Alta', 'Media', 'Baja'] as const).map((q) => (
                                <button
                                    key={q}
                                    type="button"
                                    onClick={() => setCalidad(q)}
                                    className={`
                    p-3 rounded-lg border-2 transition-all flex flex-col items-center gap-1
                    ${calidad === q
                                            ? q === 'Alta'
                                                ? 'border-success bg-success/10 text-success'
                                                : q === 'Media'
                                                    ? 'border-warning bg-warning/10 text-warning'
                                                    : 'border-destructive bg-destructive/10 text-destructive'
                                            : 'border-border bg-muted/30 text-muted-foreground hover:bg-muted/50'
                                        }
                  `}
                                >
                                    <Star className={`w-5 h-5 ${calidad === q ? 'fill-current' : ''}`} />
                                    <span className="text-sm font-medium">{q}</span>
                                </button>
                            ))}
                        </div>
                    </div>

                    <DialogFooter>
                        <Button type="button" variant="ghost" onClick={onClose}>
                            Cancelar
                        </Button>
                        <Button type="submit" variant="accent" disabled={isSubmitting}>
                            {isSubmitting ? (
                                <>
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                    Registrando...
                                </>
                            ) : (
                                'Registrar Cosecha'
                            )}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default HarvestModal;
