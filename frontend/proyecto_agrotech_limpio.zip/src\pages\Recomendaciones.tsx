import React from 'react';
import RecomendacionCard from '@/components/dashboard/RecomendacionCard';
import { recomendacionesIA } from '@/data/mockData';
import { Cpu } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const Recomendaciones: React.FC = () => {
    const handleAccept = (id: number) => {
        toast({ title: 'Recomendación aceptada', description: 'Se ha programado la acción' });
    };

    const handleReject = (id: number) => {
        toast({ title: 'Recomendación rechazada' });
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
                    <Cpu className="w-8 h-8 text-accent" />
                    Recomendaciones IA
                </h1>
                <p className="text-muted-foreground mt-1">Sugerencias inteligentes basadas en datos de sensores</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {recomendacionesIA.map((rec) => (
                    <RecomendacionCard
                        key={rec.id}
                        recomendacion={rec}
                        onAccept={handleAccept}
                        onReject={handleReject}
                    />
                ))}
            </div>
        </div>
    );
};

export default Recomendaciones;
