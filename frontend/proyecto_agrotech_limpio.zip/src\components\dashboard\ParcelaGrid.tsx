import React from 'react';
import { Parcela } from '@/types/farms';
import { Badge } from '@/components/ui/badge';
import { MapPin, Sprout, Activity, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ParcelaGridProps {
    parcelas: Parcela[];
    onParcelaClick: (parcela: Parcela) => void;
}

const ParcelaGrid: React.FC<ParcelaGridProps> = ({ parcelas, onParcelaClick }) => {
    // Colores basados en el estado de la parcela
    const estadoStyles = {
        Activa: 'border-l-success bg-success/5 text-success',
        EnMantenimiento: 'border-l-warning bg-warning/5 text-warning',
        Baja: 'border-l-destructive bg-destructive/5 text-destructive',
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {parcelas.map((parcela) => (
                <div
                    key={parcela.id}
                    onClick={() => onParcelaClick(parcela)}
                    className={cn(
                        "glass-card p-6 cursor-pointer transition-all duration-300 hover:scale-[1.02] border-l-4 group",
                        estadoStyles[parcela.estado] || 'border-l-muted'
                    )}
                >
                    {/* ENCABEZADO DE TARJETA */}
                    <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-white/5 group-hover:bg-white/10 transition-colors">
                                <MapPin className="w-5 h-5 text-avocado-pulp" />
                            </div>
                            <div>
                                <h3 className="font-display font-bold text-xl text-foreground">
                                    {parcela.nombre}
                                </h3>
                                <p className="text-sm text-muted-foreground">{parcela.area_ha} hectáreas</p>
                            </div>
                        </div>
                        <Badge variant="outline" className={cn("font-semibold", estadoStyles[parcela.estado])}>
                            {parcela.estado === 'EnMantenimiento' ? 'Mantenimiento' : parcela.estado}
                        </Badge>
                    </div>

                    {/* DETALLES RÁPIDOS */}
                    <div className="space-y-3 mt-6">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Sprout className="w-4 h-4 text-avocado-pulp/70" />
                            <span>Variedades: <b className="text-foreground/80 font-medium">Hass, Bacon</b></span>
                        </div>

                        <div className="flex items-center justify-between pt-4 border-t border-white/5">
                            <div className="flex items-center gap-2 text-xs font-medium">
                                <Activity className="w-3.5 h-3.5 text-info" />
                                <span className="text-info">2 sensores</span>
                            </div>

                            <div className="flex items-center gap-2 text-xs font-medium">
                                <AlertTriangle className="w-3.5 h-3.5 text-warning" />
                                <span className="text-warning">1 tareas</span>
                            </div>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default ParcelaGrid;