import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import HarvestModal from '@/components/dashboard/HarvestModal';
import { cosechas, siembras, parcelas, variedades } from '@/data/mockData';
import { Scale, Plus, Calendar, MapPin } from 'lucide-react';

const Cosechas: React.FC = () => {
    const [modalOpen, setModalOpen] = useState(false);

    const getCosechaInfo = (cosecha: typeof cosechas[0]) => {
        const siembra = siembras.find(s => s.id === cosecha.siembra_id);
        const parcela = siembra ? parcelas.find(p => p.id === siembra.parcela_id) : null;
        const variedad = siembra ? variedades.find(v => v.id === siembra.variedad_id) : null;
        return { siembra, parcela, variedad };
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
                        <Scale className="w-8 h-8 text-accent" />
                        Registro de Cosechas
                    </h1>
                    <p className="text-muted-foreground mt-1">Historial y registro de producción</p>
                </div>
                <Button variant="accent" onClick={() => setModalOpen(true)}>
                    <Plus className="w-4 h-4" />
                    Nueva Cosecha
                </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {cosechas.map((cosecha) => {
                    const { parcela, variedad } = getCosechaInfo(cosecha);
                    return (
                        <div key={cosecha.id} className="glass-card p-5 hover:scale-[1.02] transition-transform">
                            <div className="flex items-start justify-between mb-3">
                                <Badge variant={cosecha.calidad === 'Alta' ? 'alta' : cosecha.calidad === 'Media' ? 'media' : 'baja'}>
                                    Calidad {cosecha.calidad}
                                </Badge>
                                <span className="text-2xl font-display font-bold text-accent">
                                    {cosecha.cant_kg} kg
                                </span>
                            </div>

                            <div className="space-y-2 text-sm">
                                <div className="flex items-center gap-2 text-muted-foreground">
                                    <Calendar className="w-4 h-4" />
                                    {new Date(cosecha.fecha).toLocaleDateString('es-EC', { dateStyle: 'long' })}
                                </div>
                                {parcela && (
                                    <div className="flex items-center gap-2 text-muted-foreground">
                                        <MapPin className="w-4 h-4" />
                                        Parcela {parcela.nombre} • {variedad?.nombre}
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>

            <HarvestModal open={modalOpen} onClose={() => setModalOpen(false)} />
        </div>
    );
};

export default Cosechas;
