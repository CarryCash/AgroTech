import React, { useState } from 'react';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Package, Calendar, Hash, Ruler, Bell, Save, Loader2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface InsumoModalProps {
    open: boolean;
    onClose: () => void;
}

const InsumoModal: React.FC<InsumoModalProps> = ({ open, onClose }) => {
    const [nombre, setNombre] = useState('');
    const [tipo, setTipo] = useState('');
    const [caducidad, setCaducidad] = useState('');
    const [cantidad, setCantidad] = useState('');
    const [unidad, setUnidad] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);

        // Simulación de guardado (Conexión con tu API de .NET en el futuro)
        await new Promise((resolve) => setTimeout(resolve, 1000));

        toast({
            title: '¡Insumo Registrado!',
            description: `${nombre} ha sido añadido al inventario correctamente.`,
        });

        setIsSubmitting(false);
        onClose();
        // Limpiar formulario
        setNombre('');
        setTipo('');
        setCaducidad('');
        setCantidad('');
        setUnidad('');
    };

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="glass-card border-accent/20 sm:max-w-lg bg-[#181111] text-cream">
                <DialogHeader>
                    <div className="flex items-center gap-3 mb-2">
                        <DialogTitle className="font-display text-2xl font-bold">Registrar Nuevo Insumo</DialogTitle>
                    </div>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-6 mt-4">
                    {/* NOMBRE DEL INSUMO */}
                    <div className="space-y-2">
                        <Label htmlFor="nombre" className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                            Nombre del Insumo
                        </Label>
                        <Input
                            id="nombre"
                            placeholder="Ej: Urea Granulada"
                            value={nombre}
                            onChange={(e) => setNombre(e.target.value)}
                            className="bg-[#261c1c] border-none h-12 focus-visible:ring-1 focus-visible:ring-avocado-pulp"
                            required
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        {/* TIPO */}
                        <div className="space-y-2">
                            <Label className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Tipo</Label>
                            <Select value={tipo} onValueChange={setTipo} required>
                                <SelectTrigger className="bg-[#261c1c] border-none h-12">
                                    <SelectValue placeholder="Seleccionar tipo" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Fertilizante">Fertilizante</SelectItem>
                                    <SelectItem value="Fungicida">Fungicida</SelectItem>
                                    <SelectItem value="Herbicida">Herbicida</SelectItem>
                                    <SelectItem value="Insecticida">Insecticida</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        {/* CADUCIDAD */}
                        <div className="space-y-2">
                            <Label htmlFor="caducidad" className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                                Caducidad
                            </Label>
                            <div className="relative">
                                <Input
                                    id="caducidad"
                                    type="date"
                                    value={caducidad}
                                    onChange={(e) => setCaducidad(e.target.value)}
                                    className="bg-[#261c1c] border-none h-12 pr-10"
                                    required
                                />
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        {/* CANTIDAD INICIAL */}
                        <div className="space-y-2">
                            <Label htmlFor="cantidad" className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                                Cantidad Inicial
                            </Label>
                            <Input
                                id="cantidad"
                                type="number"
                                placeholder="0.00"
                                value={cantidad}
                                onChange={(e) => setCantidad(e.target.value)}
                                className="bg-[#261c1c] border-none h-12"
                                required
                            />
                        </div>

                        {/* UNIDAD DE MEDIDA */}
                        <div className="space-y-2">
                            <Label className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Unidad de Medida</Label>
                            <Select value={unidad} onValueChange={setUnidad} required>
                                <SelectTrigger className="bg-[#261c1c] border-none h-12">
                                    <SelectValue placeholder="Kg, L, etc." />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Kg">Kilogramos (Kg)</SelectItem>
                                    <SelectItem value="L">Litros (L)</SelectItem>
                                    <SelectItem value="Sacos">Sacos</SelectItem>
                                    <SelectItem value="Unidades">Unidades</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    {/* NOTA INFORMATIVA (ESTILO DE LA IMAGEN) */}
                    <div className="bg-[#2D5A27]/10 border border-[#2D5A27]/20 p-4 rounded-lg flex items-start gap-3">
                        <Bell className="w-5 h-5 text-[#A7C957] mt-0.5" />
                        <p className="text-sm text-gray-300">
                            <span className="text-[#A7C957] font-bold">Nota:</span> El sistema enviará una notificación automática cuando la fecha de caducidad esté próxima (30 días).
                        </p>
                    </div>

                    <DialogFooter className="gap-3 sm:gap-0">
                        <Button
                            type="button"
                            variant="ghost"
                            onClick={onClose}
                            className="text-gray-400 hover:text-white hover:bg-white/5"
                        >
                            Cancelar
                        </Button>
                        <Button
                            type="submit"
                            className="bg-[#A7C957] hover:bg-[#A7C957] text-white font-bold px-8 h-12 flex items-center gap-2"
                            disabled={isSubmitting}
                        >
                            {isSubmitting ? (
                                <Loader2 className="w-5 h-5 animate-spin" />
                            ) : (
                                <>
                                    <Save className="w-5 h-5" />
                                    Guardar Insumo
                                </>
                            )}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default InsumoModal;