import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { siembras, parcelas, variedades } from '@/data/mockData';
import { Leaf, Calendar, MapPin, Sprout, Plus, Filter } from 'lucide-react';
import AddSiembraModal from '@/components/dashboard/AddSiembraModal';
import SiembraDetalleModal from '@/components/dashboard/SiembraDetalleModal';
import { cn } from '@/lib/utils';
import { Siembra } from '@/types/farms';

const Siembras: React.FC = () => {
    // ESTADOS
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [filtroVariedad, setFiltroVariedad] = useState<string | null>(null);

    // Estados para el detalle y edición
    const [selectedSiembra, setSelectedSiembra] = useState<Siembra | null>(null);
    const [isDetailOpen, setIsDetailOpen] = useState(false);

    // Lógica de filtrado
    const siembrasFiltradas = filtroVariedad
        ? siembras.filter(s => {
            const v = variedades.find(varie => varie.id === s.variedad_id);
            return v?.nombre === filtroVariedad;
        })
        : siembras;

    // Función para abrir detalle
    const handleOpenDetail = (siembra: Siembra) => {
        setSelectedSiembra(siembra);
        setIsDetailOpen(true);
    };

    // Función para iniciar la edición desde el detalle
    const handleEditSiembra = () => {
        setIsDetailOpen(false); // Cerramos el detalle
        setIsAddModalOpen(true); // Abrimos el formulario de edición
        // Mantenemos 'selectedSiembra' para que el modal sepa qué editar
    };

    // Función para cerrar el modal de añadir/editar y limpiar selección
    const handleCloseAddModal = () => {
        setIsAddModalOpen(false);
        setSelectedSiembra(null); // Importante limpiar para que la próxima vez sea "Nueva" y no "Editar"
    };

    return (
        <div className="space-y-6 animate-fade-in">
            {/* CABECERA */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
                        <Leaf className="w-8 h-8 text-avocado-pulp" />
                        Registro de Siembras
                    </h1>
                    <p className="text-muted-foreground mt-1">Historial de plantaciones por parcela</p>
                </div>

                <Button
                    onClick={() => setIsAddModalOpen(true)}
                    className="bg-[#9BC25B] hover:bg-[#8bb34d] text-white font-bold gap-2 shadow-lg shadow-success/10 transition-colors"
                >
                    <Plus className="w-5 h-5" />
                    Nueva Siembra
                </Button>
            </div>

            {/* BARRA DE FILTROS */}
            <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-hide">
                <div className="flex items-center gap-2 text-muted-foreground mr-2">
                    <Filter className="w-4 h-4" />
                    <span className="text-xs font-bold uppercase tracking-tighter text-avocado-cream/50">Filtrar:</span>
                </div>

                <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setFiltroVariedad(null)}
                    className={cn(
                        "rounded-full border-white/10 text-xs",
                        !filtroVariedad ? "bg-avocado-pulp text-white border-avocado-pulp" : "bg-white/5 hover:bg-white/10"
                    )}
                >
                    Todas
                </Button>

                {variedades.map((v) => (
                    <Button
                        key={v.id}
                        variant="outline"
                        size="sm"
                        onClick={() => setFiltroVariedad(v.nombre)}
                        className={cn(
                            "rounded-full border-white/10 text-xs",
                            filtroVariedad === v.nombre ? "bg-avocado-pulp text-white border-avocado-pulp" : "bg-white/5 hover:bg-white/10"
                        )}
                    >
                        {v.nombre}
                    </Button>
                ))}
            </div>

            {/* GRID DE TARJETAS FILTRADAS */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {siembrasFiltradas.map((siembra) => {
                    const parcela = parcelas.find(p => p.id === siembra.parcela_id);
                    const variedad = variedades.find(v => v.id === siembra.variedad_id);

                    return (
                        <div
                            key={siembra.id}
                            onClick={() => handleOpenDetail(siembra)}
                            className="glass-card p-5 hover:scale-[1.02] cursor-pointer transition-all duration-300 border border-white/5 group"
                        >
                            <div className="flex items-start justify-between mb-3">
                                <Badge variant="outline" className="flex items-center gap-1 bg-avocado-pulp/10 text-avocado-pulp border-avocado-pulp/20 font-medium">
                                    <Sprout className="w-3 h-3" />
                                    {variedad?.nombre}
                                </Badge>
                                <div className="text-right">
                                    <span className="text-2xl font-display font-bold text-avocado-pulp group-hover:scale-110 transition-transform inline-block">
                                        {siembra.cant_plantas}
                                    </span>
                                    <span className="text-xs text-muted-foreground ml-1 uppercase font-semibold text-[10px]">Plantas</span>
                                </div>
                            </div>

                            <p className="text-[11px] text-muted-foreground mb-4 line-clamp-2 min-h-[2.5rem]">
                                {variedad?.descripcion}
                            </p>

                            <div className="space-y-3 pt-4 border-t border-white/5 text-sm">
                                <div className="flex items-center gap-2 text-muted-foreground text-xs">
                                    <Calendar className="w-4 h-4 text-avocado-pulp" />
                                    {new Date(siembra.fecha).toLocaleDateString('es-EC', { dateStyle: 'long' })}
                                </div>
                                {parcela && (
                                    <div className="flex items-center gap-2 text-muted-foreground text-xs">
                                        <MapPin className="w-4 h-4 text-avocado-pulp" />
                                        <span>Parcela <b className="text-foreground/80">{parcela.nombre}</b> ({parcela.area_ha} ha)</span>
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* MODAL PARA AÑADIR O EDITAR */}
            <AddSiembraModal
                open={isAddModalOpen}
                onClose={handleCloseAddModal}
                initialData={selectedSiembra} // Le pasamos los datos para que el formulario se llene al editar
            />

            {/* MODAL PARA VER DETALLE (POPUP) */}
            <SiembraDetalleModal
                siembra={selectedSiembra}
                parcela={parcelas.find(p => p.id === selectedSiembra?.parcela_id)}
                variedad={variedades.find(v => v.id === selectedSiembra?.variedad_id)}
                open={isDetailOpen}
                onClose={() => setIsDetailOpen(false)}
                onEdit={handleEditSiembra} // Pasamos la función de editar
            />
        </div>
    );
};

export default Siembras;