import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { trabajadores } from '@/data/mockData';
import { Users, Mail, Shield } from 'lucide-react';
import WorkerProfileModal from '@/components/dashboard/WorkerProfileModal'; // Importamos el modal nuevo
import { Trabajador } from '@/types/farms';
const Trabajadores: React.FC = () => {
    // ESTADOS PARA EL MODAL
    const [selectedWorker, setSelectedWorker] = useState<Trabajador | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const rolColors: Record<string, string> = {
        Administrador: 'bg-accent/20 text-accent border-accent/30',
        Tecnico: 'bg-info/20 text-info border-info/30',
        Peon: 'bg-muted text-muted-foreground border-white/10',
    };

    const handleOpenProfile = (worker: Trabajador) => {
        setSelectedWorker(worker);
        setIsModalOpen(true);
    };

    return (
        <div className="space-y-6 animate-fade-in">
            {/* CABECERA */}
            <div>
                <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
                    <Users className="w-8 h-8 text-avocado-pulp" />
                    Equipo de Trabajo
                </h1>
                <p className="text-muted-foreground mt-1">Gestión del personal de la finca</p>
            </div>

            {/* GRID DE TARJETAS */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {trabajadores.map((trabajador) => (
                    <div
                        key={trabajador.id}
                        onClick={() => handleOpenProfile(trabajador)}
                        className="glass-card p-5 hover:scale-[1.02] transition-all duration-300 cursor-pointer group border border-white/5 hover:border-avocado-pulp/30"
                    >
                        <div className="flex items-center gap-4">
                            {/* Avatar con iniciales */}
                            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-avocado-dark/40 to-avocado-pulp/20 flex items-center justify-center border border-white/10 group-hover:border-avocado-pulp/50 transition-colors">
                                <span className="text-xl font-display font-bold text-avocado-cream">
                                    {trabajador.nombre.split(' ').map(n => n[0]).join('')}
                                </span>
                            </div>

                            <div className="flex-1">
                                <h3 className="font-bold text-foreground group-hover:text-avocado-pulp transition-colors">
                                    {trabajador.nombre}
                                </h3>
                                <Badge variant="outline" className={rolColors[trabajador.rol]}>
                                    <Shield className="w-3 h-3 mr-1" />
                                    {trabajador.rol}
                                </Badge>
                            </div>
                        </div>

                        {/* Info de contacto rápida */}
                        <div className="mt-4 pt-4 border-t border-white/5 flex items-center gap-2 text-sm text-muted-foreground group-hover:text-cream transition-colors">
                            <Mail className="w-4 h-4 text-avocado-pulp" />
                            {trabajador.contacto}
                        </div>
                    </div>
                ))}
            </div>

            {/* COMPONENTE MODAL DE PERFIL */}
            <WorkerProfileModal
                worker={selectedWorker}
                open={isModalOpen}
                onClose={() => setIsModalOpen(false)}
            />
        </div>
    );
};

export default Trabajadores;