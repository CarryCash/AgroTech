import React from 'react';
import { Cpu, CheckCircle, XCircle, Clock, ChevronRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { RecomendacionIA } from '@/types/farm';
import { parcelas } from '@/data/mockData';
import { cn } from '@/lib/utils';

interface RecomendacionCardProps {
    recomendacion: RecomendacionIA;
    onAccept?: (id: number) => void;
    onReject?: (id: number) => void;
}

const RecomendacionCard: React.FC<RecomendacionCardProps> = ({
    recomendacion,
    onAccept,
    onReject
}) => {
    const parcela = parcelas.find(p => p.id === recomendacion.parcela_id);

    const statusConfig = {
        Pendiente: { icon: Clock, variant: 'pendiente' as const, label: 'Pendiente' },
        Aceptada: { icon: CheckCircle, variant: 'aceptada' as const, label: 'Aceptada' },
        Rechazada: { icon: XCircle, variant: 'rechazada' as const, label: 'Rechazada' },
    };

    const config = statusConfig[recomendacion.estado];
    const StatusIcon = config.icon;

    return (
        <div className={cn(
            'glass-card p-5 transition-all duration-300 hover:scale-[1.01]',
            recomendacion.estado === 'Pendiente' && 'border-l-2 border-l-warning'
        )}>
            <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                    <Cpu className="w-5 h-5 text-accent" />
                </div>

                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                        <Badge variant={config.variant} className="flex items-center gap-1">
                            <StatusIcon className="w-3 h-3" />
                            {config.label}
                        </Badge>
                        {parcela && (
                            <span className="text-xs text-muted-foreground">
                                Parcela {parcela.nombre}
                            </span>
                        )}
                    </div>

                    <p className="text-foreground font-medium mb-2">{recomendacion.descripcion}</p>

                    <p className="text-xs text-muted-foreground">
                        {new Date(recomendacion.fecha_hora).toLocaleString('es-EC', {
                            dateStyle: 'medium',
                            timeStyle: 'short',
                        })}
                    </p>
                </div>

                {recomendacion.estado === 'Pendiente' && (
                    <div className="flex items-center gap-2">
                        <Button
                            size="sm"
                            variant="success"
                            onClick={() => onAccept?.(recomendacion.id)}
                        >
                            <CheckCircle className="w-4 h-4" />
                        </Button>
                        <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => onReject?.(recomendacion.id)}
                            className="text-destructive hover:bg-destructive/10"
                        >
                            <XCircle className="w-4 h-4" />
                        </Button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default RecomendacionCard;
