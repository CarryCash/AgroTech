import React, { useState } from 'react';
import ParcelaGrid from '@/components/dashboard/ParcelaGrid';
import ParcelaDetalleModal from '@/components/dashboard/ParcelaDetalleModal';
import AddParcelaModal from '@/components/dashboard/AddParcelaModal'; // Nuevo modal
import { parcelas } from '@/data/mockData';
import { Map, Plus } from 'lucide-react'; // Añadimos Plus
import { Button } from '@/components/ui/button';
import { Parcela } from '@/types/farms';

const Parcelas: React.FC = () => {
    const [selectedParcela, setSelectedParcela] = useState<Parcela | null>(null);
    const [isDetailOpen, setIsDetailOpen] = useState(false);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false); // Estado para el nuevo modal

    const handleParcelaClick = (parcela: Parcela) => {
        setSelectedParcela(parcela);
        setIsDetailOpen(true);
    };

    return (
        <div className="space-y-6 animate-fade-in">
            {/* CABECERA CON BOTÓN AÑADIR */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
                        <Map className="w-8 h-8 text-avocado-pulp" />
                        Gestión de Parcelas
                    </h1>
                    <p className="text-muted-foreground mt-1">Administra las parcelas de la finca</p>
                </div>

                <Button
                    onClick={() => setIsAddModalOpen(true)}
                    className="bg-[#9BC25B] hover:bg-[#9BC25B] text-white font-bold gap-2 shadow-lg shadow-success/10"
                >
                    <Plus className="w-5 h-5" />
                    Nueva Parcela
                </Button>
            </div>

            {/* GRID DE PARCELAS */}
            <ParcelaGrid
                parcelas={parcelas}
                onParcelaClick={handleParcelaClick}
            />

            {/* MODAL DE DETALLE/MAPA */}
            <ParcelaDetalleModal
                parcela={selectedParcela}
                open={isDetailOpen}
                onClose={() => setIsDetailOpen(false)}
            />

            {/* MODAL DE CREACIÓN */}
            <AddParcelaModal
                open={isAddModalOpen}
                onClose={() => setIsAddModalOpen(false)}
            />
        </div>
    );
};

export default Parcelas;