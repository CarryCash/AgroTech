import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, MapPin, Play, CheckCircle } from 'lucide-react';
import type { Tarea } from '@/types/farm';
import { parcelas } from '@/data/mockData';
import { cn } from '@/lib/utils';

interface TareaCardProps {
    tarea: Tarea;
    onStart?: (id: number) => void;
    onComplete?: (id: number) => void;
    compact?: boolean;
}

const TareaCard: React.FC<TareaCardProps> = ({ tarea, onStart, onComplete, compact }) => {
    const parcela = parcelas.find(p => p.id === tarea.parcela_id);

    const estadoVariant = {
        Pendiente: 'pendiente',
        EnProgreso: 'enprogreso',
        Completada: 'completada',
        Cancelada: 'cancelada',
    } as const;

    if (compact) {
        return (
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                    <Badge variant={estadoVariant[tarea.estado]} className="text-xs">
                        {tarea.estado === 'EnProgreso' ? 'En Progreso' : tarea.estado}
                    </Badge>
                    <span className="text-sm text-foreground">{tarea.descripcion}</span>
                </div>
                <span className="text-xs text-muted-foreground">
                    {parcela?.nombre}
                </span>
            </div>
        );
    }

    return (
        <div className="glass-card p-5 hover:scale-[1.01] transition-all duration-300">
            <div className="flex items-start justify-between mb-3">
                <Badge variant={estadoVariant[tarea.estado]}>
                    {tarea.estado === 'EnProgreso' ? 'En Progreso' : tarea.estado}
                </Badge>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="w-3 h-3" />
                    {new Date(tarea.fecha_prog).toLocaleDateString('es-EC')}
                </div>
            </div>

            <h4 className="font-medium text-foreground mb-2">{tarea.descripcion}</h4>

            <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4">
                <MapPin className="w-4 h-4" />
                <span>Parcela {parcela?.nombre}</span>
            </div>

            {(tarea.estado === 'Pendiente' || tarea.estado === 'EnProgreso') && (
                <div className="flex gap-2">
                    {tarea.estado === 'Pendiente' && (
                        <Button
                            size="sm"
                            variant="outline"
                            onClick={() => onStart?.(tarea.id)}
                            className="flex-1"
                        >
                            <Play className="w-4 h-4" />
                            Iniciar
                        </Button>
                    )}
                    <Button
                        size="sm"
                        variant={tarea.estado === 'EnProgreso' ? 'success' : 'outline'}
                        onClick={() => onComplete?.(tarea.id)}
                        className="flex-1"
                    >
                        <CheckCircle className="w-4 h-4" />
                        Completar
                    </Button>
                </div>
            )}
        </div>
    );
};

export default TareaCard;
