import React from 'react';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue
} from '@/components/ui/select';
import { Sprout, Maximize2, Save } from 'lucide-react';

interface AddParcelaModalProps {
    open: boolean;
    onClose: () => void;
}

const AddParcelaModal: React.FC<AddParcelaModalProps> = ({ open, onClose }) => {
    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="glass-card border-white/10 sm:max-w-md bg-[#181111] text-cream">
                <DialogHeader>
                    <DialogTitle className="text-2xl font-display font-bold flex items-center gap-2 text-avocado-pulp">
                        <Sprout className="w-6 h-6" />
                        Nueva Parcela
                    </DialogTitle>
                </DialogHeader>

                <div className="grid gap-6 py-4">
                    {/* Nombre de la Parcela */}
                    <div className="grid gap-2">
                        <Label htmlFor="nombre" className="text-xs uppercase font-bold text-muted-foreground">Nombre de la Parcela</Label>
                        <Input
                            id="nombre"
                            placeholder="Ej: Lote Norte 01"
                            className="bg-white/5 border-white/10 focus:border-avocado-pulp/50"
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        {/* Área */}
                        <div className="grid gap-2">
                            <Label htmlFor="area" className="text-xs uppercase font-bold text-muted-foreground font-display flex items-center gap-1">
                                <Maximize2 className="w-3 h-3" /> Superficie (ha)
                            </Label>
                            <Input
                                id="area"
                                type="number"
                                placeholder="0.00"
                                className="bg-white/5 border-white/10 focus:border-avocado-pulp/50"
                            />
                        </div>

                        {/* Estado */}
                        <div className="grid gap-2">
                            <Label className="text-xs uppercase font-bold text-muted-foreground">Estado Inicial</Label>
                            <Select defaultValue="Activa">
                                <SelectTrigger className="bg-white/5 border-white/10 focus:border-avocado-pulp/50">
                                    <SelectValue placeholder="Seleccionar" />
                                </SelectTrigger>
                                <SelectContent className="bg-[#181111] border-white/10 text-cream">
                                    <SelectItem value="Activa">Activa</SelectItem>
                                    <SelectItem value="EnMantenimiento">Mantenimiento</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="p-3 rounded-lg bg-avocado-dark/20 border border-avocado-pulp/20 text-[11px] text-avocado-cream/80 italic">
                        Nota: Una vez creada, podrás configurar los sensores IoT y las variedades de aguacate desde el panel de edición.
                    </div>
                </div>

                <DialogFooter className="gap-2 sm:gap-0">
                    <Button variant="ghost" onClick={onClose} className="hover:bg-white/5 text-muted-foreground">
                        Cancelar
                    </Button>
                    <Button className="bg-avocado-pulp hover:bg-avocado-dark text-white font-bold gap-2">
                        <Save className="w-4 h-4" />
                        Guardar Parcela
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default AddParcelaModal;